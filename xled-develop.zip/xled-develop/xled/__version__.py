# -*- coding: utf-8 -*-

__title__ = "xled"  # noqa: E401
__description__ = (
    "Unofficial API documentation for Twinkly - Smart "
    "Decoration LED lights for Christmas."
)  # noqa: E401
__author__ = """Pavol Babinčák"""  # noqa: E401
__author_email__ = "scroolik@gmail.com"  # noqa: E401
# bumpversion v0.5.3 doesn't handle version string in double quotes correctly so
# prevent Black to format it:
# fmt: off
__version__ = '0.7.0'  # noqa: E401
# fmt: on
