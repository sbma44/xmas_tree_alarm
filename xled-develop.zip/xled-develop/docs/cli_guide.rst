CLI Guide
=========

Primary goal of command line interface is to provide high level way to query and control devices. It provides subset of features that devices are capable of. Tool doesn't keep any configuration and before each operation it discovers available devices. By default first device that responds is being controlled. Alternatively specified device can be controlled.

Run `xled --help` to get available options.
