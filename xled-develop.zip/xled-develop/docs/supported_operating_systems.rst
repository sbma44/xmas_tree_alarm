Supported Operating Systems
===========================

Generally both CLI and library is supported only on Linux. Most often code is tested supported Fedora and CI usually runs on Ubuntu.

It might work on other platforms where python runs but there is no guarantee. No special code for other platforms will be added.
