Supported Devices
=================

Generally device models that are listed in `Hardware section of xled-docs`_ are supported. Other models might work but there is no guarantee.


.. _`Hardware section of xled-docs`:  https://xled-docs.readthedocs.io/en/latest/hardware.html
