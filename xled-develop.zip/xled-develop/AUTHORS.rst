=======
Credits
=======

Development Lead
----------------

* Pavol Babinčák <scroolik@gmail.com>

Contributors
------------

* Paul Webster (@PaulWebster)
* Artem Ignatyev (@timon)
* Anders Holst (@Anders-Holst)
